import UIKit

var greeting = "Hello, playground"
let temp_rature = 100
if temp_rature>=100
{
    print("The water is boiling!")
}
else
{
    print("The water is not boiling")
}
let number = 73
let isTwoDigit = number>9

if !isTwoDigit
{
 print("Not a Two Digit number.")
}
else if isTwoDigit
{
 print("It is a two digit number.")
}

let month = "MAY"

switch month
{
case "january":
    print("It's January")
case "MAY":
    print("It's May")
default:
    print ("Wrong value.")
}
let temprature = 65
switch temprature
{
case Int.min..<65:
    print("It's too cold")
case 65...75:
    print("The temprature is just right")

default:
    print("It's too hot")
}
