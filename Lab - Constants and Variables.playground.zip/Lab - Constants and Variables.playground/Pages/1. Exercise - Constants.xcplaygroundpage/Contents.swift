/*:
## Exercise - Constants

 Declare a constant called `friends` to represent the number of friends you have on social media. Give it a value between 50 and 1000. Print out the value by referencing your constant.
 */


let friends = 50
print(friends)
//:  Now assume you go through and remove friends that aren't active on social media. Attempt to update your `friends` constant to a lower number than it currently is. Observe what happens and then move to the next step.


//friends = 690


print("You cannot change the value of friends because it was declared as a constant. Trying to change its value after it was originally assigned will result in a compiler error.")
/*:
page 1 of 10  |  [Next: App Exercise - Step Goal](@next)
 */
