import UIKit

var greeting = "Hello, playground"
print(greeting)
var  myage:Int = 20
print (myage)
let name="gagneesh"
print (name)
myage=30
let defaultscore = 100
var playeronescore = defaultscore
var playertwoscore = defaultscore

print (playeronescore)
print(playertwoscore)
                                               
playeronescore=200

print(playeronescore)
struct Person
{
    let firstname:String
    let lastname:String
    
    func sayHello()
    {
        print("Hello there:My name is \(firstname) \(lastname)")
        
    }}
let aperson = Person(firstname: "Gagneesh", lastname: "Singh")
aperson.sayHello()
